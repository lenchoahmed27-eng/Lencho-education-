LENCHO EDUCATION - ENTRANCE EXAM STARTER APP

Includes:
- English and Afaan Oromo interface and lesson content
- Grade selector 9, 10, 11, 12
- History, Geography, Economics and Mathematics
- Topic tabs, study notes, MCQs, correct answers and explanations
- Search lessons/questions
- Progress and scores saved in local browser storage
- Basic PWA manifest and service worker

HOW TO TEST:
1. Extract this ZIP.
2. Open index.html in a browser.
3. Choose language, grade and subject.
4. Read the note and answer the MCQ. Feedback and explanation appear after answering.

IMPORTANT:
This is a working starter prototype with sample content (16 questions across four subjects), not a complete or officially verified Ethiopian Grade 9-12 curriculum and not official past entrance-exam papers. Please check content against your current syllabus and add more questions before using it as a complete exam-preparation product.

INSTALL / PUBLISH:
Reliable PWA installation and offline support require hosting these files on an HTTPS website. This ZIP is not an Android APK and is not published on Google Play. A native APK or Play Store release requires a separate packaging, testing, signing and publishing process.
